import os

CONFIG_DIR = os.path.dirname(os.path.abspath(__file__))

CN_SCHOOLS_DIR = "{}\\cn_schools.csv".format(CONFIG_DIR)