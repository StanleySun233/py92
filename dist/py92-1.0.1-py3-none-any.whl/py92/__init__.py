import py92.py92utils
import py92.config

py92utils = py92.py92utils.py92utils()


def is_in(name):
    return name in py92utils.is_in(name)


def is_ins(names):
    return py92utils.is_ins(names)


def is_985(name):
    return py92utils.is_985(name)


def is_985s(names):
    return py92utils.is_985s(names)


def is_211(name):
    return py92utils.is_211(name)


def is_211s(names):
    return py92utils.is_211s(names)


def is_db1(name):
    return py92utils.is_db1(name)


def is_db1s(names):
    return py92utils.is_db1s(names)


def is_university(name):
    return py92utils.is_university(name)


def is_universitys(names):
    return py92utils.is_universitys(names)


def is_public(name):
    return py92utils.is_public(name)


def is_publics(names):
    return py92utils.is_publics(names)


def get_highest_label(name):
    return py92utils.get_highest_label(name)


def get_highest_labels(names):
    return py92utils.get_highest_labels(names)


def get_label(name):
    return py92utils.get_label(name)


def get_labels(names):
    return py92utils.get_labels(names)
